<?php
declare(strict_types = 1);

#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

use Yii;
use yii\base\Response;
use yii\web\Controller;
use yii\web\ErrorAction;

/**
 * Class ${NAME}
 * @package ${NAMESPACE}
 */
class ${NAME} extends Controller {

	/**
	 * @return string|Response
	 */
	public function actionIndex() {
		//TODO
	}

}
